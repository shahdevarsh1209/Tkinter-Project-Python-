quiz_data = [
    {
        "question": "Python Tkinter developed by?",
        "choices": ["Armin Ronacher", "Travis Oliphant", "John Ousterhout", "Rasmus Lerdorf"],
        "answer": "John Ousterhout"
    },
    {
        "question": "When was tkinter created?",
        "choices": ["1991", "1993", "1995", "1999"],
        "answer": "1991"
    },
    {
        "question": "Which of the following tool provides a GUI in python?",
        "choices": ["Numpy", "Scipy", "Tkinter", "Opencv"],
        "answer": "Tkinter"
    },
    {
        "question": "Which of the following we can draw using canvas in tkinter?",
        "choices": ["Oval", "Line", "Rectangle", "All of the above"],
        "answer": "All of the above"
    },
    {
        "question": "Which widget are used to get the data from the user ?",
        "choices": ["Entry", "Label", "Button", "None of the above"],
        "answer": "Entry"
    }
    # Add more questions here
]